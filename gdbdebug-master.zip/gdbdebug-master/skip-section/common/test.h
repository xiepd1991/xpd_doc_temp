class common_c
{
public:
	common_c(){}
	~common_c(){}
	int get_number(){return 100;}
};

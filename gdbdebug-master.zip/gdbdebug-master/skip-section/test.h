#include <string>
class test_c
{
public:
	test_c();
	~test_c();
	std::string get_str();
	int get_number();
	
};

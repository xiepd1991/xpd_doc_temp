#pragma once
class person
{
public:
	person(){}
	virtual ~person(){}
	virtual void work(){}
};

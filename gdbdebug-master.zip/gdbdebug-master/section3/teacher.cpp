#include "teacher.h"
#include <iostream>
using namespace std;

void teacher::work()
{
	int test = 200;
	const char*work = "teach";
	cout << "work is " << work << ",test is " << test << endl;
}

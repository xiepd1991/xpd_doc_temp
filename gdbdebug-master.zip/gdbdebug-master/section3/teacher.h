#include "person.h"
class teacher:public person
{
public:
	teacher(){}
	~teacher(){}
	void work();
};

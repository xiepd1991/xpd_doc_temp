#include "person.h"
class student:public person
{
public:
	student();
	~student();
	void work();
};

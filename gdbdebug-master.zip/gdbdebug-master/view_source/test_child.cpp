#include "test.h"

int test_child::test_member(int x,int y)
{
	int z = x*y;
	return z;
}

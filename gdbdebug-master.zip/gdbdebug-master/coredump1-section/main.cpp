
#include <thread>
#include <iostream>
#include <vector>
#include <mutex>
#include <cstring>
using namespace std;
int main()
{

	int *p = 0;
	*p = 10;
	return 0;
}

